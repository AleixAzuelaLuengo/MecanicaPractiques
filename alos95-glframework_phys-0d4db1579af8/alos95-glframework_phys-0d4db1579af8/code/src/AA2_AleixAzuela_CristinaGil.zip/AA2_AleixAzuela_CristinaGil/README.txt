Afegir Example.cpp al src del projecte i tot hauria de funcionar.
En cas de que la capsula no es renderitzi al activar-la, prova de moure la camara i t'hauria d'apareixer.